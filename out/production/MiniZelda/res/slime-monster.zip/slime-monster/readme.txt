This sprite pack contains animations for a slime-like monster.

The animations included are:
- Idle
- Walk
- Die

​Each frame has 32x32px size. It uses a NES color palette.

You can use it for personal and commercial use. Please, just don't redistribute it or call as your own.

Have fun!

-----------------------------------
Created by Adriano Veríssimo